<template></template>
<script>
  export default {
    data: function () {
      return {
        content: `
# 自我介绍

> 我叫石斌元，是一名WEB开发工程师

> 参与过一个大型项目开发，有比较丰富的项目经验（包括手机WEB、后台管理、API接口、H5、）

> 作为核心的程序员，在项目中进行 需求分析、接口设计、后台管理升级、业务代码开发 等工作

> 涉及技术点比较丰富，使用token实现权限管理、token验证身份、vue组建封装，不仅提高了程序的性能而且进行业务的解耦

> 喜欢新技术的尝试和挑战，并且有较强的专业技术，能够与同事和谐相处

---

# 联系方式

- 手机：15697259939
- Email：fireworksgirl621@gmail.com

---

# 个人信息

 - 男/2000
 - 大专/电子商务
 - 工作年限：1年（2021-09 - 2022-08）
 - 技术博客：https://blog.csdn.net/SCCSCSC?type=blog
 - Github：https://github.com/peace-god
 - 期望职位：初级前端开发工程师，初级python开发工程师
 - 期望薪资：面谈
 - 期望城市：武汉 | 上海

---

# 工作经历
### 武汉商启亿启科技有限公司 （ 2021年09月 ~ 2022年08月 ）

- 前端开发工程师
- 1.基于python 的sass商户管理后台搭建
- 2.基于Vue的商户管理系统项目开发，接口以及页面应用开发
- 3.基于Redis、Mysql、SSDB做数据存储的数据库设计
- 4.基于nuxt的Pc和H5开发，接口以及模版开发


# 技能清单

以下均为我熟练使用的技能

- Web开发：Javascript/Nodejs
- Web框架：Django
- 前端框架：HTML5/Vue/nuxt
- 前端工具：Webpack/SaSS/less
- 数据库相关：MySQL/Redis/MongoDB
- 版本管理、文档和自动化部署工具：Svn/Git

---

# 致谢
感谢您花时间阅读我的简历，期待能有机会和您共事。


        `
      }
    }
  }

  console.log('===================================================')

  console.log('===============  目前对外公开访问的项目 =====================')

  console.log('2017-2018 http://android.myapp.com/myapp/detail.htm?apkName=com.moka.cjtt')

  console.log('2014-2017： http://www.microbenefits.com/   http://www.ifuli.cn')

  console.log('2015:  PC - http://maimwu.com   Phone - http://m.maimwu.com/')

  console.log('2013:  http://www.job123.jp')

  console.log('===================================================')
</script>
